# kira-love-ai
this is a local ai named kira mainly for linux and a  presumably for mac (not tested) she can help you with installing apps and running them
