#$prerequisites$
#! /bin/bash


PS3='Please enter your choice: '
    options=("Arch" "Mac" "Debian" "Quit")
    select opt in "${options[@]}"
    do
        case $opt in
        
        
            "Arch")
    aar= df -h | sudo pacman -S python3; sudo pacman -Syyu ollama; ollama pull deepseek-r1:8b
            echo aar
        echo please run: sudo python ./kira.py
    break
                ;;


            "Mac")
    mar= df -h | (curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)
    mar2= df -h | brew install ollama &&  brew update && brew upgrade && ollama deepseek-r1:8b
            echo mar
            echo mar2
        echo please run: sudo python ./kira.py
    break
                ;;
        
        
            "Debian")
    
    dar= df -h | sudo apt-get install ollama && ollama pull deepseek-r1:8b && sudo apt-get update; sudo apt-get upgrade;
         echo please run: sudo python ./kira.py
    break
            ;;
        
        
        "Quit")
     echo bye
break

           ;;
    esac
done 

